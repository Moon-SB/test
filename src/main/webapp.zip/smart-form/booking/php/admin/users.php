<?php
	$users = array(
		"elflaire" => "04fdf4f93e6b60fc7acd94f47028ce7f", 
		"Envato" => "4a3f8e0dc6f175f2ff0e069904012453" 
	);
	$salt = substr(md5(date("F")), 8);
	$displayName = "Admin";
?>